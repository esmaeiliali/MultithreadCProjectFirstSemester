# include <iostream.h>

main ()
{

	int x, i, y1, y2, y3, y4, y5, y6, y7, y8, y9, y10;
	cin >> x;
	i = 0 ;
	if ( x>=1) {
		y1 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
		y2 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
		y3 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
		y4 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
		y5 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
		y6 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
		y7 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
	    y8 = x% 10;
	    x = x/10 ;
	}
	if ( x>=1) {
		y9 = x% 10;
		x = x/10 ;
	}
	if ( x>=1) {
		y10 = x% 10;
		x = x/10 ;
	}
	while (i<=9) {	
		if (y1==i) {
			cout << y1 ;
		} 
		if (y2==i) {
			cout << y2 ;
		}
		if (y3==i) {
			cout << y3 ;
		}
		if (y4==i) {
			cout << y4 ;
		}
		if (y5==i) {
			cout << y5 ;
		}
		if (y6==i) {
			cout << y6 ;
		} 
		if (y7==i) {
			cout << y7 ;
		}
		if (y8==i) {
			cout << y8 ;
		}
		if (y9==i) {
			cout << y9 ;
		}
		if (y10==i) {
			cout << y10 ;
		}
	i++ ;
	}






return 0;
}
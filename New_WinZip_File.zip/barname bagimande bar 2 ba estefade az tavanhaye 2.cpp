# include <iostream.h>
# include <math.h>

int main ()
{
   int x, y;
   int n = 1 ;
   cin >> x ;
   while (pow (2, n) <= x)
   {   
   while (pow (2, n) <= x)
   { y= x - pow (2, n);
     n++ ;
   }
   n= 1 ;
   x = y ;
   }
   cout << y << "\n";
return 0 ;
}
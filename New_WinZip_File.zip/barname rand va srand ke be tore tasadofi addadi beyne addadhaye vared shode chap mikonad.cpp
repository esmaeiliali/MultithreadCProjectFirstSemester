# include <iostream.h>
# include <stdio.h>
#include <stdlib.h> 
# include <time.h>

//vagti barname ra chand bar ejra mikonim choon RAND_MAX va rand har 
//do az noe addade ashari hastand banabarin tagsime anha, tagsim ashari ast
//dar natije addadhaye motafavet ra chap mikonad
//ama dar srand, be khatere eenke yek megdare avaliye darad
// va pas az an yeki yeki afzayesh miyabad
//bad az har tagriban 550 bar, yek addade jadid ro 
//chap mikonad dar natije addade tekrari masalan 13.4423342 ra 
//550 bar chap mikonad

int main() {

int i, range_min, range_max;
float u, y, t, p, a;
t= 852089012;
cin >> range_min >> range_max ;
p= range_max-range_min ;
#define RAND_MAX 0x7fff
a= RAND_MAX;
for (i=0 ; i<530; i++) {
_CRTIMP float   __cdecl srand(time(0));
u= srand/t;
y = ((u*p)+range_min) ;
printf("%.14f\n", y);

}
for (i=0 ; i<530; i++) {
	u= rand()/a;
	y= ((u*p)+range_min);
	printf("%.14f\n", y);
}

	return 0;
	
}

# include <iostream.h>
# include <math.h>

main ()
{
  
	int x, y, sum, n, t;
	sum = 0;
	n= 8 ;
	cin >> x;
	while (x>0) {
		y= x %10;
		if (y==0 || y==2 || y==4 || y==6 || y==8) {
			t = y * pow (10, n) ;
			sum = sum + t ;
			n--;
			x= x/10 ;
		}
		else {
			x= x/10 ;
		}
	}
	cout << sum / pow (10, n+1) ;
	return 0;
}

# include <iostream.h>

int main ()
{
int p;

int t[1000], i;
i = 3 ;
cin >> p ;
t [1] = 1 ;
t [2] = 1 ;
while (i<= p)
{
t[i] = t[i-1] + t[i-2] ;
i++ ;
}

while (i>1)
{
cout << t[ i-1] << " " ;
i-- ;
}
return 0 ;
}

# include <iostream.h>

int main ()

{
	int x, i, y;
	cin >> x;
	i= 1 ;
	y =1 ;
	while (y<=x)
	{
		while (i<=y){
			cout << "*" ; 
			i++;
		}
		y= y+1;
		i = 1;
		cout << "\n" ;
	}

	return 0 ;
}

#include <iostream.h>
#include <math.h>
#include <iomanip.h>

int main()
{
	long double x, a, sum, k, y;
	cin>>x;
	sum=0;
	while(x>0)
	{
		k = x ;
   int n = 1 ;
   while (pow (10, n) <= k)
   {   
   while (pow (10, n) <= k)
   { y= k - pow (10, n);
     n++ ;
   }
   n= 1 ;
   k = y ;
   }
		x=(x-k)/10;
		sum=10*sum+k;
    }
	cout << setiosflags( ios::fixed | ios::showpoint ) << setprecision(100) << sum << "\n";
	return 0;
}


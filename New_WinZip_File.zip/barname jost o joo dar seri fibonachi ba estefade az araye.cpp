# include <iostream.h>

int main ()
 
{
int p, x;
int t[1000], i;
i = 3 ;
x = 0;
cin >> p ;
t [1] = 1 ;
t [2] = 1 ;
while ( p>=i )
{
t[i] = t[i-1] + t[i-2] ;
	i++ ;
}
i = 1 ;
while (i<=p) {
while (p == t[i]) 
{
cout << "yes" ;
}
while (i<=p) {
i++ ;
while (t[i] == p) {
cout << "yes" << "\n" ;
i++;
x ++ ;
}
break ;
}}
if (x >=1)
i++ ;
	else
		cout << "no" << "\n" ;
return 0 ;
}


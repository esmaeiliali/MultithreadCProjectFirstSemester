# include <iostream.h>

int main ()
{
	int x, i, sum, tmp, y, p;
	cin >> x;
	cin >> y;
	p= 2, i=2 ;
	sum = 1 ;
	while ( i<=y) {
	while ( i<y && i>x) {
		while ( i<y && i>x) {
			if (p<y) {
				tmp = i % p;
				if (tmp==0) {
					sum = sum + p;
					p++;

				}
				else { 
					p++ ;
			}
			
			}
			if (p==y) {
				break ;
		}
		}
		if ((2*i)==sum) {
			cout << i << " ";
			i++ ;
			p=2;
			sum = 1;
		}
		else {
			i++;
			p = 2;
			sum = 1;
		}
		if (i==3)
			cout << x ;
	}
	
	i ++ ;}
	return 0 ;
}
					
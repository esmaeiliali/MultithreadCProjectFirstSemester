# include <iostream.h>
# include <math.h>
# include <stdio.h>

int main ()
{
		  unsigned int  b, u, x;
		  unsigned long int sum;
		  long double p, 
			  int z;
z= 0 ;
sum = 0;
   cin >> x ;
   while (x>=1) {
	   b= x%2 ;
	   u = x/2 ;
	   p = b * (pow (10, z));
	   z ++ ;
	   sum = sum + p ;
	   x = u ;
}
	  

cout << sum ; 
   
	  
return 0 ;
}
# include <iostream.h>
# include <math.h>

int main ()
	{	
	
	unsigned int p, y, n, i, j, t, sum, tmp, r;
	cin >> p ;
	j= 8 ;
	sum = 0 ;
	while (p>0)  {
		y = p / 10 ;
		n = p % 10;
		
		while (n==0) {
			y = p / 10 ;
			n = p % 10;
			break ;
		}
		i=1;
		t = n * pow (10, j);
		sum = sum + t;
		j-- ;
		p = y ;
	}
	j++ ;
	sum = sum / pow (10, j);
	while (sum >0 ) {
	tmp = sum % 10 ;
	r = sum /10 ;
		while (i<=tmp) 
			{
			cout << tmp;
			i ++ ;
		}
		sum = r ;
		i=1 ;
	}
	


	return 0;
}
# include <iostream.h>

main ()
{

	unsigned x1, x2, xnew, y, a, x;

	cin >>  y;
	x1= 1 ;
	x = 0;
	x2 = 1;
	while (y>=3 ){ 
		xnew = x1 + x2 ;
		a = x2 ;
		x2 = xnew;
		x1 = a ;
		if (y<=xnew) {
	if ( y == xnew ) {
		cout << "yes" << "\n" ;
		x++ ;
		break ;
	}
	else 
		break ;
		}
	}
		if (x==0) {
		cout << "no" << "\n";
		}


return 0;
}
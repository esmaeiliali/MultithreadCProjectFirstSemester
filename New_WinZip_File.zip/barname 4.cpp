# include <iostream.h>
# include <math.h>

int main ()

{

	long double x, z, y;
	int sum = 0 ;
	cin >> x;
	while (x>0) {
		z= x ;
		int n = 1; 
		while (pow (10, n) <= z)
		{   
			while (pow (10, n) <= z)
			{ 
				y= z - pow (10, n);
				n++ ;
			}
		n= 1 ;
		z = y ;
   }
	x = x/ 10 ;
    #define floorl(x)   ((long double)floor((double)(x)))
	x = floorl (x) ;
	sum = sum + z;
	}
	cout << sum ;

	return 0 ;
}

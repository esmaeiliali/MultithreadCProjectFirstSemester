# include <iostream.h>

int main ()
{
	int x, y, n, z ;
cin >> x ;
int t[1000], i;
i =0 ;
      while (x>0)  {
		y = x % 10 ;
		n = x /10 ;
		t[i] = y;	
		++i ;
		x = n; 
	  }
	  i-- ;
	  z= 0 ;
      while (z <= i) {{ 
		  cout << t[z] ;
          z++ ;
	  }}

return 0;
}
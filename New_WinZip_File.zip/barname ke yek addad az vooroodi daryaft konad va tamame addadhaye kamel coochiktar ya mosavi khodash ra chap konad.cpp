# include <iostream.h>

int main ()
{
	int x, i, sum, tmp;
	cin >> x;


	i= 2;
	sum = 1 ;
	while ( i<=x) {
		while ( i<=x) {
			if (i<=x) {
				tmp = x % i;
				if (tmp==0) {
					sum = sum + i;
					i++;
				}
				else 
					i++ ;
			}
		}
		if ((2*x)==sum) {
			cout << x << " ";
			x-- ;
			i=2;
			sum = 1;
		}
		else {
			x--;
			i = 2;
			sum = 1;
		}
		if (x==3)
			cout << x ;
	}
	return 0 ;
}
					
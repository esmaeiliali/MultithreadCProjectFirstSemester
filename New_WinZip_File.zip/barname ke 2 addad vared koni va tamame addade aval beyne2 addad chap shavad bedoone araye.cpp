# include <iostream.h>

int main ()
{
int x, y, p, q;
cin >> x;
cin >> y;
p = x+1 ;
while (p<=y-1) {
if (p==2) {
		cout << p << " ";
		p++ ;
}
else {
	if (p>=2) {
				if (p>=2 ) {
			q = 2 ;
			while (p<=y-1) {
				while  (q<= p) {
					if (p%q ==0) {
						q = 2 ;
						p++ ;
					}
					else {
						if (q<=p) {
							q ++ ;
						}
						if (q>=p) {
							cout << p << " ";
							break ;
						}
					}
					break ;}
			}
		}
		else {
			cout << " " ;
		}
	}
	else {
	p++ ;
	}
}
}

  

return 0 ;
}
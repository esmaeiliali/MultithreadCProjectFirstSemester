# include <iostream.h>
# include <stdio.h>
# include <math.h>
int main ()

{

	long double a, y, x;
	unsigned int sum = 0 ; 
	scanf("%Lf" , &a) ;
	x = a;
	while (x >0 ) {
   int n = 1 ;
   while (pow (10, n) <= x)
   {   
   while (pow (10, n) <= x)
   { y= x - pow (10, n);
     n++ ;
   }
   n= 1 ;
   x = y ;
   }
	sum = sum + y ;
	a = a /10 ;
	x = a/ 10 ;
	#define floorl(x)   ((long double)floor((double)(x)))
	x = floorl (x) ; 

	}
	printf ("%d" , sum) ;



	return 0 ;
}

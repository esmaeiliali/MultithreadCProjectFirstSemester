# include <iostream.h>

int main ()
{
	int a, j, i, x;
	float ave, sum; 

	int t[200], p;
		p = 1;
	cin >> t[0];
	while (t[p-1]>=0) {
	cin >> t[p] ;
	p++ ;
	}
    p--;
    j= 0 ;
	i = 0 ;
	while (p>= i+j) 
	{ x=0;	{	while ( p>= i+j){
				while ( t[i+j] >= t[i] ) {
								a= t[i+j] ;
                               	t[i+j] = t[i] ;
								t[i] = a;
								j++ ;
								x++ ;
				}
					while ( p>= i) {
				i ++ ;
				j=0 ;
				break ;
			}
	}
		}
	if (x>=i+1) {
		i = 0;
		j = 0;
	}
	else {
		break ;
	}
	}		
		cout << t[0] << " ";
		i= 0 ;
		sum=0 ;
		while (t[i]>=0) {
		sum = t[i] + sum ;
		i++ ;
		}
			ave = sum / p ;
		cout << ave << " ";
		i = 0 ;
		p = 0;
		while ( t[i] >= 0) {
			if (t[i]<=9){
			p++;
			i++;
		}
			else {
				i++ ;
			}
		}
		cout << p << " ";


return 0 ;
}
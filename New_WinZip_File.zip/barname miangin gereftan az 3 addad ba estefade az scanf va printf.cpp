# include <iostream.h>
# include <stdio.h>

int main ()

{
	float a, b, c, ave;
	scanf ("%f" , &a);
	scanf ("%f" , &b);
	scanf ("%f" , &c);
	ave = (a+b+c)/3 ;
	printf("%.2f" , ave);



	return 0 ;
}

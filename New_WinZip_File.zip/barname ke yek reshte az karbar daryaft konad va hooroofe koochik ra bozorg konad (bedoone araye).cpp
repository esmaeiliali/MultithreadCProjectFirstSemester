# include <iostream.h>
# include <stdio.h>
# include <conio.h>

int main ()

{
	char c;
	while ((c=getch()) !='.')
	{
		if ( c>='a' && c<= 'z' ) {
			putchar (c - 'a' + 'A' ) ;
		}
		else {
			putchar (c) ;
		}
	}

	return 0 ;
}

# include <iostream.h>

int main ()
{
	int j, i, x, p;
	float ave, sum, x1, x2, x3, x4, x5, x6, a; 
	cin >> x1 ;
	if (x1>=0) {
		cin >> x2;
		if (x2 >=0){
			cin >> x3;
			if (x3 >=0) {
				cin >> x4;
				if (x4 >=0) {
					cin >> x5;
					if (x5 >=0) {
						cin >> x6;
					}
					else

			;	}
				else
		;	}
			else
		; }
		else

;	}



	
	

  

	  j= 0 ;
		i = 0 ;
	while (6>= i+j) 
	{ x=0;	{	while ( 6>= i+j){
		if ( x2 >= x1 ) {
								a= x1 ;
                               	x1 = x2 ;
								x2 = a;
								j++ ;
								x++ ;
				}
		else 
			if ( x3 >= x2 ) {
								a= x2 ;
                               	x2 = x3 ;
								x3 = a;
								j++ ;
								x++ ;
				}
			else
					if ( x4 >= x3 ) {
								a= x3 ;
                               	x3 = x4 ;
								x4 = a;
								j++ ;
								x++ ;
				}
					else
							if ( x5 >= x4 ) {
								a= x4 ;
                               	x4 = x5 ;
								x5 = a;
								j++ ;
								x++ ;
				}
							else
									if ( x6 >= x5 ) {
								a= x5 ;
                               	x5 = x6 ;
								x5 = a;
								j++ ;
								x++ ;
				}
					while ( 6>= i) {
				i ++ ;
				j=0 ;
				break ;
			}
	}
		}
	if (x>=i+1) {
		i = 0;
		j = 0;
	}
	else {
		break ;
	}
	}		
		cout << x1 << " ";
		sum=0 ;
		x = 0;
		if (x1>=0) 
		sum = x1 + sum ;		
			if (x2>=0) 
		sum = x2 + sum ;
				if (x3>=0) 
		sum = x3 + sum ;
					if (x4>=0) 
		sum = x4 + sum ;
						if (x5>=0) 
		sum = x5 + sum ;
							if (x6>=0) 
		sum = x6 + sum ;
							else

		if (x1>=0) {
		x ++ ;
		if (x2 >=0){
			x++;
			if (x3 >=0) {
				x++;
				if (x4 >=0) {
					x++ ;
					if (x5 >=0) {
						x++ ;
						if (x6>= 0) {
							x++ ;
						}
						else
					; }
					else

			;	}
				else
		;	}
			else
		; }
		else

;	}

		ave = sum / x ;
	cout << ave << " " ;

		x=0 ;
		if ( x1 >= 0) {
			if ( x1 <= 9)
				x ++ ;
					if ( x2 >= 0) 
			if ( x2 <= 9)
				x ++ ;
					if ( x3 >= 0) 
			if ( x3 <= 9)
				x ++ ;
					if ( x4 >= 0) 
			if ( x4 <= 9)
				x ++ ;
					if ( x5 >= 0) 
			if ( x5 <= 9)
				x ++ ;
				if ( x6 >= 0) 
			if ( x6 <= 9)
				x ++ ;
		cout << x << " ";

		}
return 0 ;
}
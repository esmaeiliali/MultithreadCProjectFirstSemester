# include <iostream.h>
# include <stdio.h>
# include <math.h>
int main ()

{
	unsigned int x, tmp, y, z;
	int i ;
	cin >> x;
	i= 0 ;
	tmp = 2 ;
	if (x>1) {
	while (x>1) {
		while (x>1) {
			y = x % tmp ;
			if (y== 0) {
				x = x / tmp;
				i++ ;
			}
			else {
				if (i==0) {
					tmp ++ ;
					break ;
				}
				else {
					cout << tmp << "^" << i << "*" ;
					tmp ++ ;
					i = 0 ;
					break ;
			}

		}
		}

	}
	cout << tmp << "^" << i << "\n" ;
		return 0 ;
	}
	else {
	return 0 ;
	}
}

# include <iostream.h>

main ()
{

	unsigned x1, x2, xnew, y, a;

	cin >>  y;
	x1= 1 ;
	x2 = 1;
	cout << x1 << " " ;
	cout << x2 << " " ;
	while (y>=3 )
	{ xnew = x1 + x2 ;
	a = x2 ;
	x2 = xnew;
	x1 = a ;
	y-- ;
	cout << xnew << " " ;
	}

return 0;
}
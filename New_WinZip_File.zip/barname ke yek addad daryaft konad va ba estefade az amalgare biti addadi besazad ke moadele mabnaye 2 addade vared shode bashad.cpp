# include <iostream.h>
main ()
{
	int x, y, ;
	y = 0x80000000 ;
	cin >> x;
	while (y)
	{
		if (x & y) { 
		cout << 1;
		}
		else {
		cout << 0;
		}
		y = (unsigned int)y>>1 ;
	}

	return 0;
}
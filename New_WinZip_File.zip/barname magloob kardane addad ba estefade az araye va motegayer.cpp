# include <iostream.h>

int main ()
{
   int x, y, n, j, k;
cin >> x ;
cin >> j ;
cin >> k ;

int t[1000], i;
i = j+k ;
      while (x>0)  {
		y = x % 10 ;
		n = x /10 ;
		t[i] = y;	
		++i ;
		x = n;
}
	while (i>j+k)
	{
		cout << t[j+k] ;
        j++ ;
	}
return 0 ;
}